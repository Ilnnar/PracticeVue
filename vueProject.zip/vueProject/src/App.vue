<script setup>
  import {ref} from 'vue';
  
  const name = 'Frank';
  const activo = true;

  const counter = ref(0);
  //metodo
  const clickAumentar = () => {
    counter.value++;
  }
  const clickDisminuir = () => {
    counter.value--;
  }
  const clickResetear = () => {
    counter.value = 0;
  }
</script>

<template>
  <h1>
    Hola {{ name.toUpperCase() }}
  </h1>
  <h2>Estoy utilizando VUE</h2>
  <p v-if="activo">Soy desarrollador activo</p>
  <p v-else>Soy desarrollador inactivo</p>
  <h2 :class="counter < 0 ? 'negativo' : 'positivo'">
    {{ counter }}
  </h2>
  <div class="btnContainer">
    <button @click="clickAumentar" class="btnClick">
      Aumentar
    </button>
    <button @click="clickDisminuir" class="btnClick">
      Disminuir
    </button>
    <button @click="clickResetear" class="btnClick">
      Resetear
    </button>
  </div>
</template>

<style>
  h1{
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    align-content: center;
    justify-items: center;
  }
  .btnContainer{
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    align-content: center;
    flex-direction: column;
  }
  .btnClick{
    height: 60px;
    width: 110px;
    font-size: 20px;
    margin-top: 10px;
  }
  .negativo{
    font-size: 30px;
    color: red;
  }
  .positivo{
    font-size: 30px;
    color: black;
  }
</style>